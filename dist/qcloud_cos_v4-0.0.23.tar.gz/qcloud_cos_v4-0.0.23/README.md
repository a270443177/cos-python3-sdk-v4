Qcloud COSv4 SDK
#######################


介绍
_______

Cos Python3 SDK, 目前可以支持Python3.x。

安装指南
__________

使用pip安装::

    pip install -U qcloud3_cos_v4

手动安装::

    python setup.py install

使用方法
__________

使用python sdk，参照官网的python sdk

https://github.com/tencentyun/cos-python-sdk-v4
